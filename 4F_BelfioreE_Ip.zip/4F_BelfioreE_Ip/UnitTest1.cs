namespace _4F_BelfioreE_Ip;

public class IPAddressTests
{
    [Fact]
    public void Constructor_ValidIPAddress_ShouldCreateInstance()
    {
        string ipAddress = "192.168.1.1";

        var ip = new IPAddress(ipAddress);

        Assert.NotNull(ip);
    }

    [Theory]
    [InlineData("192.168.1.1", "255.255.255.0")]
    [InlineData("10.0.0.1", "255.0.0.0")]
    public void GetNetworkAddress_ShouldReturnCorrectNetworkAddress(string ipAddress, string netmask)
    {
        var ip = new IPAddress(ipAddress);
        ip.SetNetMask(netmask);

        var networkAddress = ip.GetNetworkAddress();

        Assert.Equal("192.168.1.0", networkAddress);
    }
}