global using Xunit;
class IpAddress
{
    private uint _ipAddress;
    private uint _netmask;

    public IpAddress(string ipAddress)
    {
        if (!ValidateIPAddress(ipAddress))
        {
            throw new ArgumentException("Invalid IP address format.");
        }

        _ipAddress = ConvertToUInt32(ipAddress);
    }

    public void SetNetMask(string netmask)
    {
        _netmask = ConvertToUInt32(netmask);
    }

    public string GetNetMask()
    {
        return ConvertToDottedDecimal(_netmask);
    }

    public string GetNetworkAddress()
    {
        uint networkAddress = _ipAddress & _netmask;
        return ConvertToDottedDecimal(networkAddress);
    }

    public string GetBroadcastAddress()
    {
        uint invertedNetmask = ~_netmask;
        uint broadcastAddress = _ipAddress | invertedNetmask;
        return ConvertToDottedDecimal(broadcastAddress);
    }

    public string GetFirstHostAddress()
    {
        uint networkAddress = _ipAddress & _netmask;
        uint firstHostAddress = networkAddress + 1;
        return ConvertToDottedDecimal(firstHostAddress);
    }

    public string GetLastHostAddress()
    {
        uint invertedNetmask = ~_netmask;
        uint broadcastAddress = _ipAddress | invertedNetmask;
        uint lastHostAddress = broadcastAddress - 1;
        return ConvertToDottedDecimal(lastHostAddress);
    }

    private bool ValidateIPAddress(string ip)
    {
        string[] octets = ip.Split('.');
        if (octets.Length != 4)
        {
            return false;
        }

        foreach (string octet in octets)
        {
            if (!byte.TryParse(octet, out byte result))
            {
                return false;
            }
        }

        return true;
    }

    private uint ConvertToUInt32(string ipAddress)
    {
        string[] octets = ipAddress.Split('.');
        uint result = 0;
        for (int i = 0; i < 4; i++)
        {
            result <<= 8;
            result |= uint.Parse(octets[i]);
        }
        return result;
    }

    private string ConvertToDottedDecimal(uint number)
    {
        return $"{(number >> 24) & 255}.{(number >> 16) & 255}.{(number >> 8) & 255}.{number & 255}";
    }
}